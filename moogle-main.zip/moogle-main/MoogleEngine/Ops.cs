namespace MoogleEngine
{
    public class Ops
    {
        public static Dictionary<string,double> CleanDocs(Dictionary<string,Dictionary<string,double>> DocumentTF, 
        string[] QueryDividido,string[] QueryClean, Dictionary<string,double> DocScores, Dictionary<string,string[]> DocumentoDividido){
            //    foreach (var item in QueryDividido)
            //    {
            //        System.Console.WriteLine(item);
            //    }
        
        //Este metodo recibe el diccionario grande de <documentos, Diccionario<palabras del documento,TF> que es DOcumentTF
        //Recibe un string[] con las palabras de la query sin caracteres pero con operadores QueryDividido
        //Recibe un string[] con las palabras de la query sin caracteres y sin operadores QueryClean
        //Recibe un Diccionario de <string,double> con <nombre de documento, score del documento> DocScores
        //Y recibe un diccionario de <string,string[]> con <nomre del documento, array de string con las palabras del documento en cada posicion
        
        //Este metodo va a aplicar los 4 operadores, !  ^  *  ~


    //Operador ! es el operador que indica que esa palabra no debe aparecer en ningun documento
    //Ejemplo algoritmo !ordenacion, la palabra ordenacion no debe aparecer en ningun documento
    //Aplicar este operador


    DocScores = NoPuedeExistir(DocumentTF, QueryDividido, QueryClean, DocScores);


    //Operador ^ es el operador que indica que esa palabra tiene que aparecer en todos los documentos devueltos 

    DocScores = ObligadoExistir(DocumentTF, QueryDividido, QueryClean, DocScores);

        // foreach (var item in DocScores)
        // {
        //     System.Console.WriteLine(item.Value+"    :    "+ item.Key);
        // }




    for(int i = 0; i<QueryDividido.Length; i++){
    //Este for va recorriendo las palabras del query y verificando la existencia de los operadores
       
            
           
            //ESte es el operador *
           if(QueryDividido[i].Contains("*")){
                //Aqui me verifica si el operador * existe delante de alguna palabra, si existe entro al foreach

                //Tengo que contar las veces que aparece el operador *
                int count = 1;
                foreach (var charact in QueryDividido[i])
                {
                    if(charact=='*'){
                        count++;
                    }
                }
                //Count es la cantidad de veces que aparece el operador * mas una vez mas;
                System.Console.WriteLine(count);

                foreach (var doc in DocScores)
                {//Este me va recorriendo el diccionario de <documento,score>

                    if(DocumentTF[doc.Key].ContainsKey(QueryClean[i])){
                        //Comprueba si el diccionario grande de <documentos, Diccionario<palabras del documento,TF>, donde estan todas las palabras que tiene cada documento
                        //Si en ese documento existe la palabra que tenia delante el operador *, entonces
                        //EN el diccionario de <documentos,score> el score lo multiplico por count

                        DocScores[doc.Key]=DocScores[doc.Key]*count;
                   

                    }
                }

               
            }
            
            if(QueryDividido[i].StartsWith("~")){
                
                
                if(i==0){
                    break;
                }

                foreach (var doc in DocScores)
                {   
                    if(DocumentTF[doc.Key].ContainsKey(QueryClean[i])&DocumentTF[doc.Key].ContainsKey(QueryClean[i-1])){
                               
                        double distancia = distance(DocumentoDividido[doc.Key],QueryClean[i],QueryClean[i-1]);
                        
                        if(distancia == 0){
                        
                            DocScores[doc.Key] = 1+DocScores[doc.Key];
                        
                        }else{
                        
                        distancia = 1/distancia;
                        DocScores[doc.Key] = distancia + DocScores[doc.Key];
                        
                        }
                        
                        
                    }


                }          
                
            }


    }


    return DocScores;

    }
private static Dictionary<string,double> NoPuedeExistir(Dictionary<string,Dictionary<string,double>> DocumentTF, string[] QueryDividido, string[] QueryClean, Dictionary<string,double> DocScores){

for(int i = 0; i<QueryDividido.Length; i++){
    //Este for va recorriendo las palabras del query y verificando la existencia de los operadores

        
            if(QueryDividido[i].Contains("!")){
                //Aqui me verifica si el operador ! existe en alguna palabra, si existe entro al foreach

                foreach (var doc in DocScores)
                {//Este me va recorriendo el diccionario de <documento,score>

                    if(DocumentTF[doc.Key].ContainsKey(QueryClean[i])){
                        //Comprueba si el diccionario grande de <documentos, Diccionario<palabras del documento,TF>, donde estan todas las palabras que tiene cada documento
                        //Si en ese documento existe la palabra que tenia delante el operador !




                        /* Poner el if en los resultados para cuando todas las palabras del quey tenga ! delante, en ese caso devolver normal los resultados
                         En el caso de que haya alguna palabra sin ! quitar las que tienen score 0 */
                        DocScores.Remove(doc.Key);

                    }
                }
            }
}

return DocScores;

}

private static Dictionary<string,double> ObligadoExistir(Dictionary<string,Dictionary<string,double>> DocumentTF, string[] QueryDividido, string[] QueryClean, Dictionary<string,double> DocScores){



for(int i = 0; i<QueryDividido.Length; i++){
    //Este for va recorriendo las palabras del query y verificando la existencia de los operadores
       
            
            if(QueryDividido[i].Contains("^")){
                //Aqui me verifica si el operador ^ existe delante de alguna palabra, si existe entro al foreach

                foreach (var doc in DocScores)
                {//Este me va recorriendo el diccionario de <documento,score>

                    if(!DocumentTF[doc.Key].ContainsKey(QueryClean[i])){
                        //Comprueba si el diccionario grande de <documentos, Diccionario<palabras del documento,TF>, donde estan todas las palabras que tiene cada documento
                        //Si en ese documento existe la palabra que tenia delante el operador !

                        DocScores.Remove(doc.Key);

                    }
                }
            }

}

return DocScores;




}




    
private static int distance(string[] texto,string palabra1,string palabra2)
{
    //Metodo para calcular la menor distancia entre dos palabras
       

    if (palabra1.Equals( palabra2) )

        return 0 ;

   
  

    int min_dist = (texto.Length) + 1;
    //Como la maxima distancia mayor entre dos palabras es el length + 1

   

    for (int i = 0;i < texto.Length ; i++)

    {

   

        if (texto[i].Equals(palabra1))

        {

            for (int search = 0; search < texto.Length; search ++) 

            {

                if (texto[search] .Equals(palabra2)) 

                {
                    /*La distancia entre las dos palabras es la posiciones de la palabra1 menos la posicion de la palabra 2 menos 1
                    Porque si hay 5 palabras, y contamos la 1 palabra esta en la pos 0 y la 4 palabra en la pos 3, entre la 1 y la 4 
                    esta la 2 palabra y la 3ra palabra, pero 3-0 = 3 por eso se le resta 1*/

                    int curr = Math.Abs(i - search) - 1; 

   
                    //Comparando curr distancia con la distancia guardada anteriormente

                    if (curr < min_dist) 

                    {

                        min_dist = curr ;

                    }

                }

            }

        }

    }

       
    return min_dist;
}

    }
}